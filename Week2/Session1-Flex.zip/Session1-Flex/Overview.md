# Office Hours
    - Q & A 
    - Refresher and explanation on how img tags work
    - Wind down before lecture


# Flexbox

    - The lego concept

    - the display property

    - display: flex; - Should always be applied to the parent of the elements you are trying to organize

    - inline-block - all children of an element with display flex are inline-block elements

    - Justify Content (justify-content) - Organize elements horizontally (or in a row)

    - Align Items (align-items) - Organize elements vertically (or in a column)

    - Flex Direction (flex-direction) - Turns the axis of the project

    - Other properties not commonly used  (flex-grow, flex-shrink, flex-wrap, flex-basis, align/justify-self -> flex:1)

    - Why use flex? - Simply because its easier and requires much less code

    - What does flex do? - A lot of new features of languages are automated processes using old ways.


    # After Hours Group Assignment